<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>wander</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="3"/>
        <source>Wander</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="4"/>
        <source>Causes the entity to move to a series of randomly chosen locations for the specified amount of time. Wandering can be constrained to a specified area.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="6"/>
        <source>Movement/Move_To_Cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="7"/>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="8"/>
        <source>Choose whether the entity will wander indefinitely or for a fixed amount of time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="9"/>
        <source>Wander Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="11"/>
        <source>Movement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander.cxx" line="13"/>
        <source>Wander Area (Optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/wander_script.cxx" line="80"/>
        <source>Could not start async job</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
