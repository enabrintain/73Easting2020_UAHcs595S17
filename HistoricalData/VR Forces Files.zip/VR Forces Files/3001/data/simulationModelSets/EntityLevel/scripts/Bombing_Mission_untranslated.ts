<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Bombing_Mission</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="3"/>
        <source>Execute Close Air Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="4"/>
        <source>Execute a call for Close Air Support (CAS) using 9-line brief parameters to engage a named target.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="5"/>
        <source>Engagement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="6"/>
        <source>Engagement/DtVrfTaskFireCruiseMissileAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="7"/>
        <source>9-Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="9"/>
        <source>1. Initial Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="10"/>
        <source>Also refered to as the Battle Position.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="11"/>
        <source>2. Heading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="12"/>
        <source>The heading from the IP to TGT in degrees magnetic. This parameter does not affect flight.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="13"/>
        <source>Offset: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="14"/>
        <source>Offset direction inidcates the side of the IP target line to attacking aircraft can manoeuvre to position itself for the attack.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="15"/>
        <source>3. Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="16"/>
        <source>The distance to the target. This parameter does not affect flight.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="17"/>
        <source>4-6. Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="18"/>
        <source>Provides the name of the target to hit. The location is calcuated. For automatic attacks the description is not needed. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="19"/>
        <source>7. Mark Type: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="20"/>
        <source>Describe the type of mark used on the target. This parameter is not used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="21"/>
        <source>Laser Code: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="22"/>
        <source>Laser designator code.  If entered, some entity must be designating the target with a laser of this code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="23"/>
        <source>8. Friendlies: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="24"/>
        <source>The location of friendly forces nearest the target. This parameter is not used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="25"/>
        <source>9. Egress Heading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="26"/>
        <source>Heading to fly after bomb release.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="27"/>
        <source>Attack Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="29"/>
        <source>Weapon Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="30"/>
        <source>Whether to drop bombs or strafe with guns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="31"/>
        <source>Bomb Choice: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="32"/>
        <source>The type of bomb to drop.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="33"/>
        <source>Bombing Altitude:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bombing_Mission.cxx" line="34"/>
        <source>Choose to stay at the current altitude or use the aircraft maximum altitude when dropping a bomb.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
