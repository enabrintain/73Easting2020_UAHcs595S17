<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Talk_To_Friends</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="3"/>
        <source>Talk to Friends...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="4"/>
        <source>Entity wanders and randomly approaches and talks to other nearby entities running this same task.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="6"/>
        <source>Movement/DtVrfTaskTurnToHeadingAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="7"/>
        <source>Friend Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="8"/>
        <source>Maximum distance from entity to query for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="9"/>
        <source>Restrict to Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="10"/>
        <source>Select to restrict entity movement to the specified area.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="11"/>
        <source>Area:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Talk_To_Friends.cxx" line="12"/>
        <source>If Restrict to Area is selected, the area in which to restrict movement.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
