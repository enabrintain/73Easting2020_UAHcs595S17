<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Bounding_Overwatch_Move_To</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="3"/>
        <source>Bounding Overwatch Move To...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="4"/>
        <source>Designed for small aggregates of humans.  Simple behavior that moves half of an aggregate at a time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="6"/>
        <source>Movement/DtConvoyAlongTaskAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="7"/>
        <source>Destination:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="9"/>
        <source>Overwatch Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="10"/>
        <source>Maximum seperation between elements of the group as they move.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="11"/>
        <source>Movement Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="13"/>
        <source>Threat Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bounding_Overwatch_Move_To.cxx" line="14"/>
        <source>Heading to the threat.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
