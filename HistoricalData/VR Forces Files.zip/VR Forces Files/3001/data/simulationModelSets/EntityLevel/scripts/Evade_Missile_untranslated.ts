<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Evade_Missile</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Evade_Missile.cxx" line="3"/>
        <source>Evade Missile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Evade_Missile.cxx" line="4"/>
        <source>Attempts to evade an incoming missile.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Evade_Missile_script.cxx" line="20"/>
        <source>Expiring missile: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Evade_Missile_script.cxx" line="57"/>
        <source>Missile incoming!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Evade_Missile_script.cxx" line="84"/>
        <source>Missile getting farther away.  Ending task</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
