<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Dump_Surface_Info</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Surface_Info.cxx" line="3"/>
        <source>Dump Surface Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Surface_Info.cxx" line="4"/>
        <source>Calls terrainHeightUnderWaterDebug at the entity&apos;s location to print out information about what terrain surfaces are there, and how they are being interpreted wrt Ground and Water.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
