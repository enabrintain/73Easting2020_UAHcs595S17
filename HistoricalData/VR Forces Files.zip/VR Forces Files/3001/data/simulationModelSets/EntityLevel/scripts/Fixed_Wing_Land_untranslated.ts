<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Fixed_Wing_Land</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Land.cxx" line="3"/>
        <source>Fixed Wing Land</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Land.cxx" line="4"/>
        <source>Creates a route that lines up with the first point of the runway at an appropriate altitude, and descends as it approaches the runway. Flies the aircraft on that route and then lands the plane using an animation sequence to describe the motion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Land.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Land.cxx" line="6"/>
        <source>Movement/Fixed_Wing_Takeoff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Land.cxx" line="7"/>
        <source>Runway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Land.cxx" line="8"/>
        <source>A route identifying the location and extent of the runway. Two points are sufficient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Land_script.cxx" line="151"/>
        <source>Setting approach speed: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
