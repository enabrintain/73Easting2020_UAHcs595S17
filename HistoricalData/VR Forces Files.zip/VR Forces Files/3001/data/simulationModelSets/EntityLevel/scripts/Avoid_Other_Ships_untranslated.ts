<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Avoid_Other_Ships</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Avoid_Other_Ships.cxx" line="3"/>
        <source>Avoid Other Ships</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Avoid_Other_Ships.cxx" line="4"/>
        <source>Reactive task to avoid other ships. Considers ship type: aircraft carrier is higher than fishing boat (with nets out), which is higher than sailboat, which is higher than other. Avoids surfaced submarines.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Avoid_Other_Ships_script.cxx" line="594"/>
        <source>   Error: no movement system found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Avoid_Other_Ships_script.cxx" line="602"/>
        <source>   Error: could not get ordered speed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
