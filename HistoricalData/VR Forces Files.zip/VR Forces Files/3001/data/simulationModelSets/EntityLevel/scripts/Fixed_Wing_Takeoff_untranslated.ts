<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Fixed_Wing_Takeoff</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff.cxx" line="3"/>
        <source>Fixed Wing Takeoff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff.cxx" line="4"/>
        <source>Taxis the entity to the runway start, plays an animation to execute a takeoff and initial climb, then starts a fly-heading task in the same direction. If taking off from an entity it is embarked on, it will disembark when it takes off.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff.cxx" line="6"/>
        <source>Movement/DtVrfTaskFollowEntityAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff.cxx" line="7"/>
        <source>Runway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff.cxx" line="8"/>
        <source>A route that describes the runway. Use only two points.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff_script.cxx" line="40"/>
        <source>Fixed-wing-takeoff unable to find movement system in entity; aborting task.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff_script.cxx" line="69"/>
        <source>Takeoff Acceleration: %1 Time: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff_script.cxx" line="91"/>
        <source>Disembarking at frame %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Takeoff_script.cxx" line="117"/>
        <source>Ready to takeoff</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
