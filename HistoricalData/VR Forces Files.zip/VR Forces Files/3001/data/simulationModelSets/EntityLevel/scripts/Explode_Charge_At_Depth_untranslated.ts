<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Explode_Charge_At_Depth</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Explode_Charge_At_Depth.cxx" line="3"/>
        <source>Explode Charge At Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Explode_Charge_At_Depth.cxx" line="4"/>
        <source>Sets the entity to descend to the given depth, and explodes it when it reaches that depth.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Explode_Charge_At_Depth.cxx" line="5"/>
        <source>Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Explode_Charge_At_Depth.cxx" line="6"/>
        <source>Depth at which the charge will explode.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
