<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Deploy_Sonobuoys_Along_Route</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="3"/>
        <source>Deploy Sonobuoys Along Route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="4"/>
        <source>Moves the entity along the given route, dropping a sonobuoy at the beginning of the route and all along the route at the given spacing. The sonobuoys set their sonar active at the given depth.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="5"/>
        <source>Route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="6"/>
        <source>Route to deploy sonobuoys along</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="7"/>
        <source>Sonobuoy Spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="8"/>
        <source>Distance between sonbuoys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="9"/>
        <source>Sonar Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="11"/>
        <source>Sonar Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoys_Along_Route.cxx" line="12"/>
        <source>Depth of buoy&apos;s sonar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
