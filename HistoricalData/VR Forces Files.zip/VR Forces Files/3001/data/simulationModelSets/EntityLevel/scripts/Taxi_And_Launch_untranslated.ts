<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Taxi_And_Launch</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="3"/>
        <source>Taxi and Launch from Carrier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="4"/>
        <source>Taxis aircraft to designated catapult and launches it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="6"/>
        <source>Movement/$(menutext)&gt;Movement/DtVrfTaskMoveToLocationAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="7"/>
        <source>Route (optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="8"/>
        <source>Create a route to a point close to the destination.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="9"/>
        <source>Catapult</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="10"/>
        <source>The 2-point route that models the catapult track.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="11"/>
        <source>Holding Pattern After Takeoff?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="12"/>
        <source>Does the aircraft enter a holding pattern after takeoff?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="13"/>
        <source>Hold Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_And_Launch.cxx" line="14"/>
        <source>Altitude of the holding pattern</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
