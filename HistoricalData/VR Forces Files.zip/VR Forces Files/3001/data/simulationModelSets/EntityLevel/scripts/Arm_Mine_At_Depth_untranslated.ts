<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Arm_Mine_At_Depth</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="3"/>
        <source>Arm Mine At Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="4"/>
        <source>Sets the depth to which the mine will descend and wait, and sets its trigger to the given target types, hostility, and proximity. The mine is armed after the given delay after it reaches its depth.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="5"/>
        <source>Mine Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="6"/>
        <source>Depth to which mine will sink and wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="7"/>
        <source>Detonate Proximity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="8"/>
        <source>Radius in which the mine will explode when an entity is sensed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="9"/>
        <source>Arming Delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="10"/>
        <source>The time delay before the mine is armed, after it reaches the specified depth.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="11"/>
        <source>Trigger Entity Types:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="12"/>
        <source>What types of entities will trigger the mine.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="13"/>
        <source>Hostile Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Arm_Mine_At_Depth.cxx" line="14"/>
        <source>Whether only hositle entities can trigger the mine.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
