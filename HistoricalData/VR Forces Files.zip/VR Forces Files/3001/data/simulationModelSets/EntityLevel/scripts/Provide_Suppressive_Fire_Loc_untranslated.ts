<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Provide_Suppressive_Fire_Loc</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="3"/>
        <source>Provide Suppressive Fire at Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="4"/>
        <source>Lays down suppressive fire on a location. Fire is aimed 1m above the ground at the location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="6"/>
        <source>Engagement/$(menutext)&gt;Engagement/DtVrfTaskFireAtTargetAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="7"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="8"/>
        <source>Click on map for target location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="9"/>
        <source>Duration of Rapid Fire (seconds): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="10"/>
        <source>Duration of initial, rapid fire </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="11"/>
        <source>Total Fire Time (minutes): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="12"/>
        <source>Total firing time (rapid followed by sustained fire).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="13"/>
        <source>Maximum Rounds To Fire: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="14"/>
        <source>Max number of rounds entity should shoot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="15"/>
        <source>Gun: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire_Loc.cxx" line="16"/>
        <source>Select which gun on the entity to use for suppressive fire.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
