<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Dump_Terrain_Intersection_Info</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Terrain_Intersection_Info.cxx" line="3"/>
        <source>Dump Terrain Intersection Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Terrain_Intersection_Info.cxx" line="4"/>
        <source>Gets all intersections between the given chord and the terrain and dumps information about them to the simulation console. Blocks waiting for the operation to finsih.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Terrain_Intersection_Info.cxx" line="5"/>
        <source>Start Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Terrain_Intersection_Info.cxx" line="6"/>
        <source>The first point of the chord along which to test intersections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Terrain_Intersection_Info.cxx" line="7"/>
        <source>End Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Dump_Terrain_Intersection_Info.cxx" line="8"/>
        <source>The second point of the chord along which to test intersections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
