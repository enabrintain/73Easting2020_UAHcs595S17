<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Bingo_Fuel_Monitor</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="3"/>
        <source>Bingo Fuel Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="4"/>
        <source>Monitors fuel remaining on this embedded entity, printing various status messages and requesting a recovery (RTB) operation when bingo fuel is reached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="6"/>
        <source>Parent: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="7"/>
        <source>This Embedded Entity&apos;s parent object name.  (The unit that can recover it.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="8"/>
        <source>My Embedded Name: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="9"/>
        <source>This Embedded Entity&apos;s embedded entity name - basically how the parent addresses it within the context of the Embedded Entity system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="10"/>
        <source>Fuel economy (km/unit): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="11"/>
        <source>Km traveled per unit fuel.  Usually 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="12"/>
        <source>Bingo Fuel: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="13"/>
        <source>The fuel safety margin to add to usage estimates before RTB.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="14"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="16"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="18"/>
        <source>Joker Fuel: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="15"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="17"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Bingo_Fuel_Monitor.cxx" line="19"/>
        <source>As with bingo fuel but for status messaging.  Will be ignored if not greater than bingo fuel.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
