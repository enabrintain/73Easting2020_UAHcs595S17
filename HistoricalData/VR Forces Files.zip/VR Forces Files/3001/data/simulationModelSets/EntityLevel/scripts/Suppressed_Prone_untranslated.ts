<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Suppressed_Prone</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Suppressed_Prone.cxx" line="3"/>
        <source>Suppressed Prone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Suppressed_Prone.cxx" line="4"/>
        <source>Forces the entity to stop and fall prone when suppressed to level 2 or 3. Resumes movment at old posture when no longer suppressed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Suppressed_Prone.cxx" line="6"/>
        <source>The priority of this reactive task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Suppressed_Prone.cxx" line="8"/>
        <source>Whether or not this reactive task is enabled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
