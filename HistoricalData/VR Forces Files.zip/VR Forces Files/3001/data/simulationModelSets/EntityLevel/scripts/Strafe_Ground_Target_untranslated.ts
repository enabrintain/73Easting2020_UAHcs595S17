<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Strafe_Ground_Target</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="3"/>
        <source>Strafe Ground Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="4"/>
        <source>Execute a call for Close Air Support (CAS) using guns.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="5"/>
        <source>Engagement/$(menutext)&gt;Engagement/Bombing_Mission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="6"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="8"/>
        <source>Initial Point:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="7"/>
        <source>Initial Point, from which the aircraft will begin its strafing attack. If used, do not also specify IP Location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="9"/>
        <source>Initial point to start attack from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="10"/>
        <source>Target Point:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="11"/>
        <source>The location of the strafing target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="12"/>
        <source>Target Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="13"/>
        <source>The specific types of entities to target.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="14"/>
        <source>Abort Without Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="15"/>
        <source>If true, and no target entities are acquired, the strafing mission will abort. Otherwise, the task will fire at the target point if it can&apos;t acquire targets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="16"/>
        <source>Egress Maneuver:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="17"/>
        <source>The initial egress maneuver. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Strafe_Ground_Target.cxx" line="18"/>
        <source>Final Egress Heading</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
