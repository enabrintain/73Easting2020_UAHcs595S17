<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Sonar_Dip</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="3"/>
        <source>Sonar Dip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="4"/>
        <source>Moves the entity to the given location, then turns on a sonar at the given depth. The sonar is left on for the given duration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="5"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="6"/>
        <source>Location of sonar dip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="7"/>
        <source>Duration: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="8"/>
        <source>Time to spend dipping sonar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="9"/>
        <source>Sonar Type: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="10"/>
        <source>The type of sonar to use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="11"/>
        <source>Sonar Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Sonar_Dip.cxx" line="12"/>
        <source>Sets sonar to this depth</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
