<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Launch_ASW_Missile</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="3"/>
        <source>Launch Anti-Submarine Missile (Vertical)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="4"/>
        <source>Launches a missile that flies out to the vicinity of the target submarine and then drops a homing torpedo. The type of missile and torpedo are determined by the system that provides this task. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="6"/>
        <source>Engagement/$(menutext)&gt;Engagement/Launch torpedo/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="7"/>
        <source>Target Entity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="8"/>
        <source>The target vessel. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="9"/>
        <source>Drop Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="10"/>
        <source>Location where the missile converts to a torpedo and drops to the water.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="11"/>
        <source>Parent Platform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile.cxx" line="12"/>
        <source>Parent platform that launched the torpedo. Must be the character &apos;-&apos; when this task is run on the launching platform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile_script.cxx" line="64"/>
        <source>Error: unable to launch munition; launcher set-attribute error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile_script.cxx" line="67"/>
        <source>Launching ASW missile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile_script.cxx" line="116"/>
        <source>Error: launcher could not create missile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile_script.cxx" line="132"/>
        <source>Could not start fly-heading task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile_script.cxx" line="153"/>
        <source>Missile unable to perform torpedo launch task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Launch_ASW_Missile_script.cxx" line="165"/>
        <source>Illegal missile task state</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
