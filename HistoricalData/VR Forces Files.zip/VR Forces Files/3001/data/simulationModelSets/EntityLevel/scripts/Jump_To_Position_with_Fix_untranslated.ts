<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Jump_To_Position_with_Fix</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="3"/>
        <source>Jump To Position with Fix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="4"/>
        <source>Makes the entity immediately jump to the given position. The position is identified by a point, a bearing, a range, and an altitude.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="6"/>
        <source>Movement/animated-movement-task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="7"/>
        <source>Fix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="8"/>
        <source>The reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="9"/>
        <source>Bearing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="10"/>
        <source>The bearing from the fix of the desired postion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="11"/>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="12"/>
        <source>The distance from the fix of the desired position.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="13"/>
        <source>Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Jump_To_Position_with_Fix.cxx" line="14"/>
        <source>The altitude of the desired position</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
