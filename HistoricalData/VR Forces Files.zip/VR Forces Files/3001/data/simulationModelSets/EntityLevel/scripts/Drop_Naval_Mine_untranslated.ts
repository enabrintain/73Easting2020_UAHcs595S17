<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Drop_Naval_Mine</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="3"/>
        <source>Drop Naval Mine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="4"/>
        <source>Drop a naval mine at the entity&apos;s current location. The mine will descend to the given depth, and then after the given delay, arm itself. It will be triggered by the given target types, hostility, and proximity.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="5"/>
        <source>Engagement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="6"/>
        <source>Engagement/Bombing_Mission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="7"/>
        <source>Naval Mine:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="9"/>
        <source>Mine Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="10"/>
        <source>Depth to which the mine will descend and wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="11"/>
        <source>Arming Delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="12"/>
        <source>Amount of time after reaching final depth to arm the mine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="13"/>
        <source>Detonate Proximity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="14"/>
        <source>Target proximity that will trigger the mine to explode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="15"/>
        <source>Target Types:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="16"/>
        <source>Entity types that will trigger detonation of mine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="17"/>
        <source>Hostile Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Mine.cxx" line="18"/>
        <source>Indicates that only hostile entities will trigger the mine.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
