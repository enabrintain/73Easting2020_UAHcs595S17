<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Automatic_Headlights</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Automatic_Headlights.cxx" line="3"/>
        <source>Automatic Headlights</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Automatic_Headlights.cxx" line="4"/>
        <source>Turn on and off headlights and taillights based on local lighting conditions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Automatic_Headlights.cxx" line="6"/>
        <source>The priority of this reactive task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Automatic_Headlights.cxx" line="8"/>
        <source>Whether or not this reactive task is enabled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
