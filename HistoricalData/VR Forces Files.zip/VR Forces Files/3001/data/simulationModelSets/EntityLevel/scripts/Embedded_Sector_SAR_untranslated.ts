<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Embedded_Sector_SAR</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="3"/>
        <source>Sector Search Operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="4"/>
        <source>Finds an embedded entity available on this object and tasks it with a sector search and rescue task.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="5"/>
        <source>$(menutext)&gt;Explode_Charge_At_Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="6"/>
        <source>Allow Diversion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="7"/>
        <source>Enables this task to divert a deployed embedded entity from its current task if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="8"/>
        <source>Recover When Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="9"/>
        <source>If selected, parent&apos;s plan does not advance until the SAR pattern is finished. Parent then recovers the embedded entity. If cleared, parent advances its plan while the embedded entity executes the SAR pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="12"/>
        <source>Commence Search Point (CSP):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="13"/>
        <source>Centerpoint of the SAR pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="14"/>
        <source>Leg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="15"/>
        <source>length of trackline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="16"/>
        <source>Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="17"/>
        <source>Search altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="18"/>
        <source>Air Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Embedded_Sector_SAR.cxx" line="19"/>
        <source>Speed of search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
