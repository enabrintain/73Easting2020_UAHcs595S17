<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>disaggregated_flee</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/disaggregated_flee.cxx" line="3"/>
        <source>Flee...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/disaggregated_flee.cxx" line="4"/>
        <source>Flee from given target(s) within radius until hidden (if checked) or radius is reached.  This task will be considered complete when all entities have sucessfully fleed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/disaggregated_flee.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/disaggregated_flee.cxx" line="6"/>
        <source>Movement/bhave-flee-task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/disaggregated_flee.cxx" line="9"/>
        <source>Radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/disaggregated_flee.cxx" line="11"/>
        <source>Stop When Hidden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
