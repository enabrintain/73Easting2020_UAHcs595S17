<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Monitor_Terrain</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Monitor_Terrain.cxx" line="3"/>
        <source>Monitor Terrain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Monitor_Terrain.cxx" line="4"/>
        <source>Monitors changes in terrain type as an entity moves and displays them at Warn level.  Set Notify level to Debug to get the altitude of the terrain when a terrain change is detected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Monitor_Terrain.cxx" line="5"/>
        <source>Other/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Monitor_Terrain.cxx" line="6"/>
        <source>Other/Lower_Periscope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Monitor_Terrain_script.cxx" line="24"/>
        <source>Invalid terrain intersection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Monitor_Terrain_script.cxx" line="28"/>
        <source>Now on terrain type: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
