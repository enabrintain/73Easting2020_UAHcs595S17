<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Close_Cargo_Door</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Close_Cargo_Door.cxx" line="3"/>
        <source>Close Cargo Door</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Close_Cargo_Door.cxx" line="5"/>
        <source>Cargo Door/$(menutext)&gt;Movement/</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
