<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Naval_Mine_Sweep</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="3"/>
        <source>Sweep Naval Mines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="4"/>
        <source>Sweep for mines along a route and disarm (and delete) those within range. The error rate is the percentage chance of failing to deactivate a mine within range.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="6"/>
        <source>Movement/DtVrfTaskPatrolObjectsAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="7"/>
        <source>Sweep Route:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="8"/>
        <source>The route along which to sweep for mines.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="9"/>
        <source>Sensing Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="10"/>
        <source>The range from the entity at which mines can be disarmed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="11"/>
        <source>Disarm Failure Probability (%):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Naval_Mine_Sweep.cxx" line="12"/>
        <source>Probability that a mine within range will not be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
