<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ZigHeading</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="3"/>
        <source>Zig-Zag to Heading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="4"/>
        <source>This task moves a ship in a given heading using a Zig-Zag pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="5"/>
        <source>Movement/$(menutext)&gt;Movement/DtVrfTaskMoveToAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="6"/>
        <source>Heading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="7"/>
        <source>Direction of travel (Deg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="8"/>
        <source>Leg Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="9"/>
        <source>The time in minutes on each leg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="10"/>
        <source>Leg Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/ZigHeading.cxx" line="11"/>
        <source>Angle of offset for each leg</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
