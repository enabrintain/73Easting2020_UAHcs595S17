<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="to_TO">
<context>
    <name>Move_to_Named_Street</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_to_Named_Street.cxx" line="3"/>
        <source>Move to Named Street</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_to_Named_Street.cxx" line="4"/>
        <source>Searches within the given range for the given street name and moves to the closest point on the street.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_to_Named_Street.cxx" line="5"/>
        <source>Movement/$(menutext)&gt;Movement/DtVrfTaskMoveToLocationAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_to_Named_Street.cxx" line="6"/>
        <source>Street Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_to_Named_Street.cxx" line="8"/>
        <source>Search Range:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
