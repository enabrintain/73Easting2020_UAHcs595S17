<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Drop_Naval_Depth_Charge</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="3"/>
        <source>Drop Naval Depth Charge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="4"/>
        <source>Create a munition entity corresponding to the given depth charge resource.  The depth charge will descend to the given depth and explode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="5"/>
        <source>Engagement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="6"/>
        <source>Engagement/Bombing_Mission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="7"/>
        <source>Type of Depth Charge:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="8"/>
        <source>The type of depth charge to drop.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="9"/>
        <source>Explode at Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge.cxx" line="10"/>
        <source>The altitude at which the charge explodes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_script.cxx" line="57"/>
        <source>Could not create naval depth charge of type %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
