<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Make_Way_for_Emergency</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Make_Way_for_Emergency.cxx" line="3"/>
        <source>Make Way for Emergency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Make_Way_for_Emergency.cxx" line="4"/>
        <source>Vehicles will pull over to the side of the road when an emergency vehicle with its lights on approaches.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
