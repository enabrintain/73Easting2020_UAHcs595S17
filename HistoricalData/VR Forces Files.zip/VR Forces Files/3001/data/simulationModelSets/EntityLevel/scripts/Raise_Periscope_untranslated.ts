<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Raise_Periscope</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Raise_Periscope.cxx" line="3"/>
        <source>Raise Periscope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Raise_Periscope.cxx" line="4"/>
        <source>Raises the periscope, antenna, snorkel, and </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Raise_Periscope.cxx" line="5"/>
        <source>Other/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Raise_Periscope.cxx" line="6"/>
        <source>Other/DtVrfTaskUserTaskAction</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
