<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Deploy_Sonobuoy</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy.cxx" line="3"/>
        <source>Deploy Sonobuoy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy.cxx" line="4"/>
        <source>Drops (creates) a sonobuoy at the terrain surface and activates its sonar to operate at the given depth.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy.cxx" line="5"/>
        <source>Sonar Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy.cxx" line="7"/>
        <source>Sonar Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy.cxx" line="8"/>
        <source>Depth of buoy&apos;s sonar sensor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy_script.cxx" line="29"/>
        <source>No sonobuoy resource found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy_script.cxx" line="34"/>
        <source>No sonobouys remaining.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Deploy_Sonobuoy_script.cxx" line="66"/>
        <source>Waiting for terrain data to be available</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
