<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Create_and_Move_To_Waypoint</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Create_and_Move_To_Waypoint.cxx" line="3"/>
        <source>Create and Move to Waypoint...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Create_and_Move_To_Waypoint.cxx" line="4"/>
        <source>Create a waypoint at the chosen location and send the entity to it at the ordered speed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Create_and_Move_To_Waypoint.cxx" line="5"/>
        <source>Movement/$(menutext)&gt;Movement/DtConvoyToTaskAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Create_and_Move_To_Waypoint.cxx" line="6"/>
        <source>Waypoint Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Create_and_Move_To_Waypoint.cxx" line="7"/>
        <source>Where to create the waypoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Create_and_Move_To_Waypoint.cxx" line="8"/>
        <source>Ordered Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Create_and_Move_To_Waypoint.cxx" line="9"/>
        <source>Speed at which to move to the waypoint</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
