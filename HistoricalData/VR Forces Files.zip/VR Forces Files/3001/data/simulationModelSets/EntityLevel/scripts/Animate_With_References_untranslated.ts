<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Animate_With_References</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="3"/>
        <source>Animate with References</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="4"/>
        <source>This uses the built in </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="6"/>
        <source>Movement/AircraftHold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="7"/>
        <source>Animation Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="9"/>
        <source>Reference Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="11"/>
        <source>Reference Heading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="13"/>
        <source>Reference Theta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Animate_With_References.cxx" line="14"/>
        <source>Reference pitch angle with respect to the earth&apos;s tangent plane.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
