<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Attack_Aircraft_with_Guns</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Attack_Aircraft_with_Guns.cxx" line="3"/>
        <source>Attack Aircraft with Guns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Attack_Aircraft_with_Guns.cxx" line="4"/>
        <source>Fly toward the target aircraft and when within range, shoot guns at it; then break off.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Attack_Aircraft_with_Guns.cxx" line="5"/>
        <source>Engagement/$(menutext)&gt;Engagement/Strafe_Ground_Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Attack_Aircraft_with_Guns.cxx" line="6"/>
        <source>Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Attack_Aircraft_with_Guns.cxx" line="7"/>
        <source>Target aircraft entity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
