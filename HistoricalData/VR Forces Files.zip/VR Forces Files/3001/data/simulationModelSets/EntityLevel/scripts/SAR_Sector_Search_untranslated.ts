<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>SAR_Sector_Search</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="3"/>
        <source>Sector Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="4"/>
        <source>Perform a SAR Sector search pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="5"/>
        <source>Movement/Search and Rescue/$(menutext)&gt;Movement/Search and Rescue/SAR_Parallel_Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="6"/>
        <source>Commence Search Point (CSP):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="7"/>
        <source>Where search starts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="8"/>
        <source>Leg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="9"/>
        <source>length of trackline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="10"/>
        <source>Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="11"/>
        <source>Search Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="12"/>
        <source>Air Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Sector_Search.cxx" line="13"/>
        <source>Spead of search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
