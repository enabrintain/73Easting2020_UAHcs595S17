<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Fixed_Wing_Carrier_Land</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Carrier_Land.cxx" line="3"/>
        <source>Land on Carrier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Carrier_Land.cxx" line="4"/>
        <source>Flies the aircraft on an approach and then lands it on the angled flight deck of the carrier (indicated by the selected route).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Carrier_Land.cxx" line="6"/>
        <source>Movement/$(menutext)&gt;Movement/Taxi_And_Launch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Carrier_Land.cxx" line="7"/>
        <source>Runway Route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Carrier_Land.cxx" line="8"/>
        <source>A route object defining the carrier landing area.The first point of the route should be the beginning of the deck, and the second should be at the 3rd wire.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Fixed_Wing_Carrier_Land_script.cxx" line="267"/>
        <source>Setting approach speed: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
