<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Place_IED</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="3"/>
        <source>Place IED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="4"/>
        <source>Tasks an entity to move to a location, place an IED, and then move away to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="5"/>
        <source>Engagement/$(menutext)&gt;Engagement/DtVrfTaskLaseTargetAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="6"/>
        <source>Placement Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="7"/>
        <source>Location at which to place the IED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="8"/>
        <source>Placement Duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="9"/>
        <source>Length of time it takes to place the IED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="10"/>
        <source>Fuse Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="11"/>
        <source>Chooses the type of fuse to arm the IED with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="12"/>
        <source>Time Delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="13"/>
        <source>Amount of time set on the timed fuse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="14"/>
        <source>Proximity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="15"/>
        <source>Proximity at which to detonate a proximity fuse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="16"/>
        <source>Post Placement Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="17"/>
        <source>Location to move to after the IED has been placed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="18"/>
        <source>Arming Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Place_IED.cxx" line="19"/>
        <source>Choose to arm the fuse at the placement location or at the post-placement location</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
