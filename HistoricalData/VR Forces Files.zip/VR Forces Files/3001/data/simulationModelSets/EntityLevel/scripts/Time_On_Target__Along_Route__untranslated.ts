<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Time_On_Target__Along_Route_</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route_.cxx" line="3"/>
        <source>Time On Target (Along Route)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route_.cxx" line="4"/>
        <source>Travel along the route, adjusting speed to arrive at the last point on the route at the specified simulation time.  A hold pattern will be executed at the start of the route, if the arrival time is too far in the future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route_.cxx" line="5"/>
        <source>Movement/$(menutext)&gt;Movement/DtVrfTaskRotaryWingLandAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route_.cxx" line="6"/>
        <source>Route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route_.cxx" line="7"/>
        <source>Route to move along.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route_.cxx" line="8"/>
        <source>Time On Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route_.cxx" line="9"/>
        <source>Arrival time for the end of the route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route__script.cxx" line="100"/>
        <source>Adjusting speed: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route__script.cxx" line="109"/>
        <source>Missed time on target.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Time_On_Target__Along_Route__script.cxx" line="143"/>
        <source>Cannot reach target by specified time.  Expecting to arrive %1 seconds late.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
