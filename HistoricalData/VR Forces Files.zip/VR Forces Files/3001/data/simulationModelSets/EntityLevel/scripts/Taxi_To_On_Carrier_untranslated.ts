<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Taxi_To_On_Carrier</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="3"/>
        <source>Taxi On Carrier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="4"/>
        <source>Makes aircraft taxi to a position and assume a final heading.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="6"/>
        <source>Movement/$(menutext)&gt;Movement/DtVrfTaskMoveToLocationAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="7"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="8"/>
        <source>Click on map to set destination point on carrier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="9"/>
        <source>Route (optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="10"/>
        <source>Create a route to a point close to the destination.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="11"/>
        <source>Assume Final Heading?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="12"/>
        <source>Should the entity be placed at a specific heading at its destination?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="13"/>
        <source>Final Heading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Taxi_To_On_Carrier.cxx" line="14"/>
        <source>The heading the aircraft will assume when it gets to its destination.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
