<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Conversation</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Conversation.cxx" line="3"/>
        <source>Conversation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Conversation.cxx" line="4"/>
        <source>Let&apos;s you build conversations for DI-Guys. Only works with male and female adult civilians and crowd civilians.  Male and female civilians have 5 talk animations. Male and female civilian crowd entities have 9 and 10 animations. The script automatically figures out which kind of entity you selected and assigns it the correct tasks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Conversation.cxx" line="5"/>
        <source>Repetitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Conversation.cxx" line="6"/>
        <source>The number of tasks to execute. Each task takes 2-5 seconds. So 20 repetitions is about one minute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Conversation.cxx" line="7"/>
        <source>Task Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Conversation.cxx" line="8"/>
        <source>Sequential from starting tasks picks a task at random and then cycles through the task list in order. Random jumps around somewhat randomly.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
