<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Lower_Periscope</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Lower_Periscope.cxx" line="3"/>
        <source>Lower Periscope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Lower_Periscope.cxx" line="4"/>
        <source>Lowers the periscope, antenna, snorkel, and </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Lower_Periscope.cxx" line="5"/>
        <source>Other/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Lower_Periscope.cxx" line="6"/>
        <source>Other/DtVrfTaskUserTaskAction</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
