<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>SAR_Creep_Pattern</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="3"/>
        <source>Creep Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="4"/>
        <source>Perform a SAR Creep Pattern flight path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="5"/>
        <source>Movement/Search and Rescue/$(menutext)&gt;Movement/Search and Rescue/SAR_Parallel_Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="6"/>
        <source>Commence Search Point (CSP):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="7"/>
        <source>Where search starts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="8"/>
        <source>Major Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="10"/>
        <source>Minor Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="11"/>
        <source>Minor Axis of search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="12"/>
        <source>Leg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="13"/>
        <source>length of trackline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="14"/>
        <source>Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="15"/>
        <source>Also known as creep distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="16"/>
        <source>Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="17"/>
        <source>Search Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="18"/>
        <source>Air Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="19"/>
        <source>Spead of search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="20"/>
        <source>Legs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/SAR_Creep_Pattern.cxx" line="21"/>
        <source>Number of passes to make</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
