<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AircraftHold</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="3"/>
        <source>Pattern Hold (Location)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="4"/>
        <source>Enter a standard hold pattern, using direct, parallel, or teardrop entry as appropriate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="5"/>
        <source>Movement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="6"/>
        <source>Movement/DtConvoyAlongTaskAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="7"/>
        <source>Holding Fix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="8"/>
        <source>Fix point for the holding pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="9"/>
        <source>Heading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="10"/>
        <source>Heading of pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="11"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="12"/>
        <source>Speed to fly while holding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="13"/>
        <source>Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="14"/>
        <source>Altitude to fly while holding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="15"/>
        <source>Turn Direction:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="16"/>
        <source>Direction of turns in the holding pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AircraftHold.cxx" line="17"/>
        <source>Release Time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
