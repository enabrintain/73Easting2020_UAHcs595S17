<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Drop_Naval_Depth_Charge_At_Location</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="3"/>
        <source>Drop Naval Depth Charge At Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="4"/>
        <source>Move the entity to the given location, then drop (create) a depth charge of the given type. The charge will descend to the given depth and explode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="5"/>
        <source>Engagement/$(menutext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="6"/>
        <source>Engagement/Bombing_Mission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="7"/>
        <source>Naval Depth Charge:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="8"/>
        <source>The type of depth charge to create.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="9"/>
        <source>Explode at Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="10"/>
        <source>The depth the charge will sink to and explode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="11"/>
        <source>Drop Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="12"/>
        <source>The location the entity will move to before dropping the charge.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="13"/>
        <source>Use Current Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Drop_Naval_Depth_Charge_At_Location.cxx" line="14"/>
        <source>Regardless of what the drop location altitude is set to be, use the altitude of the entity at the time the task is executed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
