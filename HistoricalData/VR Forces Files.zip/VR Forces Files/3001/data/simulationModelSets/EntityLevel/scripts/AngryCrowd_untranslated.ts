<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AngryCrowd</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AngryCrowd.cxx" line="3"/>
        <source>Angry Crowd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AngryCrowd.cxx" line="4"/>
        <source>Let&apos;s you build angry crowds for DI-Guys. Only works with male and female adult civilians and crowd civilians.  Male and female civilians have 4 angry animations. 10 repetitions takes about 1:15 min. Male and female civilian crowd entities have 7 angry animations. 10 repetitions takes about 3 min.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AngryCrowd.cxx" line="5"/>
        <source>Repetitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AngryCrowd.cxx" line="6"/>
        <source>The number of tasks to execute. Each task takes 2-5 seconds. So 20 repetitions is about one minute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AngryCrowd.cxx" line="7"/>
        <source>Task Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/AngryCrowd.cxx" line="8"/>
        <source>Sequential from starting task picks a task at random and then executes each task in order. Random picks tasks randomly.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
