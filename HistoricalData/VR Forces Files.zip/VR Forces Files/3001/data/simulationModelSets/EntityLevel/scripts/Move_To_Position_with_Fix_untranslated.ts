<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Move_To_Position_with_Fix</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="3"/>
        <source>Move To Position with Fix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="4"/>
        <source>Starts the entity moving to the position defined with a fix, a bearing, a range, and an altitude.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="5"/>
        <source>Movement/$(menutext)&gt;Movement/ship-navigate-to-waypoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="6"/>
        <source>Fix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="7"/>
        <source>The reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="8"/>
        <source>Bearing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="9"/>
        <source>The bearing from the fix of the desired postion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="10"/>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="11"/>
        <source>The distance from the fix of the desired position.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="12"/>
        <source>Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Move_To_Position_with_Fix.cxx" line="13"/>
        <source>The altitude of the desired position</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
