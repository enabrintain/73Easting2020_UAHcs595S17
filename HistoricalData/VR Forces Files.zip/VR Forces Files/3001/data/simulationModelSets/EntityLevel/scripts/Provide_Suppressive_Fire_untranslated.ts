<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Provide_Suppressive_Fire</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="3"/>
        <source>Provide Suppressive Fire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="4"/>
        <source>Lays down suppressive fire on a target. Fire is directed at a point, along a line, or in an area. Fire is aimed 1m above the terrain. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="7"/>
        <source>Engagement/$(menutext)&gt;Engagement/DtVrfTaskFireAtTargetAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="8"/>
        <source>Target Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="9"/>
        <source>Choose a point (or entity), line, or area.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="11"/>
        <source>Initial rapid fire duration, and total duration and ammo limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="12"/>
        <source>Duration of Rapid Fire (seconds): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="13"/>
        <source>Duration of initial, rapid fire </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="14"/>
        <source>Total Fire Time (minutes): </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="15"/>
        <source>Total firing time (rapid followed by sustained fire).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="16"/>
        <source>Maximum Rounds To Fire: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="17"/>
        <source>Max number of rounds entity should shoot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="18"/>
        <source>Gun: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="19"/>
        <source>Select which gun on the entity to use for suppressive fire.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="20"/>
        <source>Target Location: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate2/Provide_Suppressive_Fire.cxx" line="21"/>
        <source>Click on the map to select a target location.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
