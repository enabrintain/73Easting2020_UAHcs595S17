<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Entity_Categories</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Circle (Extruded)3.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Circle1.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Corridor2.cxx" line="8"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Route7.cxx" line="8"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Text8.cxx" line="7"/>
        <source>Shapes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Circle (Extruded)3.cxx" line="8"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Corridor2.cxx" line="9"/>
        <source>Extruded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class I18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class II18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class III18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class IV18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class IX18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class V18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VI18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VII18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VIII18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Supply Point18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Text8.cxx" line="8"/>
        <source>Logistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Coordination Point18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Decision Point18.cxx" line="7"/>
        <source>Maneuver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Corridor2.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Phase Line6.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Route7.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Sink18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Spawn20.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Waypoint18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Waypoint9.cxx" line="7"/>
        <source>Control Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Point of Interest18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Text8.cxx" line="9"/>
        <source>Intel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Target Point18.cxx" line="7"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Target Point9.cxx" line="7"/>
        <source>Fire Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Text8.cxx" line="10"/>
        <source>Symbols</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Entity_Labels</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Circle (Extruded)3.cxx" line="3"/>
        <source>Circle (Extruded)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Circle1.cxx" line="3"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class I18.cxx" line="3"/>
        <source>Class I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class II18.cxx" line="3"/>
        <source>Class II</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class III18.cxx" line="3"/>
        <source>Class III</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class IV18.cxx" line="3"/>
        <source>Class IV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class IX18.cxx" line="3"/>
        <source>Class IX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class V18.cxx" line="3"/>
        <source>Class V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VI18.cxx" line="3"/>
        <source>Class VI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VII18.cxx" line="3"/>
        <source>Class VII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VIII18.cxx" line="3"/>
        <source>Class VIII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Coordination Point18.cxx" line="3"/>
        <source>Coordination Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Corridor2.cxx" line="3"/>
        <source>Corridor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Decision Point18.cxx" line="3"/>
        <source>Decision Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Global Plan5.cxx" line="3"/>
        <source>Global Plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Phase Line6.cxx" line="3"/>
        <source>Phase Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Point of Interest18.cxx" line="3"/>
        <source>Point of Interest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Route7.cxx" line="3"/>
        <source>Route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Sink18.cxx" line="3"/>
        <source>Sink</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Spawn20.cxx" line="3"/>
        <source>Spawn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Supply Point18.cxx" line="3"/>
        <source>Supply Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Target Point18.cxx" line="3"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Target Point9.cxx" line="3"/>
        <source>Target Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Text8.cxx" line="3"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Waypoint18.cxx" line="3"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Waypoint9.cxx" line="3"/>
        <source>Waypoint</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Entity_Short_Names</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Circle (Extruded)3.cxx" line="19"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Circle1.cxx" line="18"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class I18.cxx" line="18"/>
        <source>Class I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class II18.cxx" line="18"/>
        <source>Class II</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class III18.cxx" line="18"/>
        <source>Class III</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class IV18.cxx" line="18"/>
        <source>Class IV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class IX18.cxx" line="18"/>
        <source>Class IX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class V18.cxx" line="18"/>
        <source>Class V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VI18.cxx" line="18"/>
        <source>Class VI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VII18.cxx" line="18"/>
        <source>Class VII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Class VIII18.cxx" line="18"/>
        <source>Class VIII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Coordination Point18.cxx" line="18"/>
        <source>Coordination Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Corridor2.cxx" line="20"/>
        <source>Corridor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Decision Point18.cxx" line="18"/>
        <source>Decision Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Phase Line6.cxx" line="18"/>
        <source>Phase Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Point of Interest18.cxx" line="18"/>
        <source>Point of Interest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Route7.cxx" line="19"/>
        <source>Route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Sink18.cxx" line="18"/>
        <source>Sink</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Spawn20.cxx" line="18"/>
        <source>Spawn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Supply Point18.cxx" line="18"/>
        <source>Supply Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Target Point18.cxx" line="18"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Target Point9.cxx" line="18"/>
        <source>Target Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Text8.cxx" line="21"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Waypoint18.cxx" line="18"/>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/Waypoint9.cxx" line="18"/>
        <source>Waypoint</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Forces</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/forces0.cxx" line="3"/>
        <source>Friendly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/forces0.cxx" line="4"/>
        <source>Opposing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/forces0.cxx" line="5"/>
        <source>Neutral</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>area_object_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/area-object-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/area-object-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/area-object-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/area-object-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>circle_object_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/circle-object-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/circle-object-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/circle-object-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/circle-object-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>global_environment_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/global-environment-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/global-environment-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/global-environment-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/global-environment-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>line_object_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/line-object-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/line-object-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/line-object-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/line-object-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>point_object_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/point-object-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/point-object-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/point-object-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/point-object-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>simulation_object_group</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/simulation-object-group.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/simulation-object-group.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/simulation-object-group.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/simulation-object-group.cxx" line="6"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/simulation-object-group.cxx" line="7"/>
        <source>simulation_object_group_widget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>symbol_object_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/symbol-object-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/symbol-object-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/symbol-object-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/symbol-object-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>text_object_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/text-object-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/text-object-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/text-object-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/text-object-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>vrf_object_param</name>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/vrf-object-param.cxx" line="3"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/vrf-object-param.cxx" line="4"/>
        <source>general_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/vrf-object-param.cxx" line="5"/>
        <source>display_widget_canvas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="C:/Users/nightbus/AppData/Local/Temp/_translate5/vrf-object-param.cxx" line="6"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
